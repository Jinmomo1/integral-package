#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]

double Tintegral(double a, double b, double Epsilon, Function fun)
{
  double T1;
  T1 = (b-a)/2*(as<double>(fun(a))+as<double>(fun(b)));
  double Tn = T1;
  double T2n = 0;
  double e = 0.1;
  int N = 1;
  while (e > Epsilon) {
    double Y = 0;
    double x = 0;
    double dx = (b - a) / (N);
    for (int i = 1; i <= N; i++)
    {
      x = a + (2 * i - 1) * dx / 2.0;
      Y = as<double>(fun(x)) + Y;
    }

    T2n = 0.5 * (Tn + (b - a) / N * Y);
    e = fabs(T2n - Tn);
    N = 2 * N;
    Tn = T2n;
  }
  return T2n;
}


// [[Rcpp::export]]

double Pintegral(double a, double b, double Epsilon, Function fun)
{
  double e = 0.1;
  int N = 1;
  double Tn = (b-a) / 2*(as<double>(fun(a))+4*as<double>(fun((a+b)/2))+as<double>(fun(b)));
  double T2n = 0;
  while (e > Epsilon) {
    double Y = 0;
    double dx = (b - a) / (2 * N);
    for (int i = 1; i <= N; i++)
    {
      double x2kmins2 = a + (2 * i - 2) * dx;
      double x2kmins1 = a + (2 * i - 1) * dx;
      double x2k = a + (2 * i) * dx;
      double y = dx * (as<double>(fun(x2kmins2)) + 4 * as<double>(fun(x2kmins1)) + as<double>(fun(x2k)));
      Y = Y + y;
    }
    N = 2 * N;
    T2n = Y / 3.0;
    e = fabs(T2n - Tn);
    Tn = T2n;
  }
  return T2n;
}
